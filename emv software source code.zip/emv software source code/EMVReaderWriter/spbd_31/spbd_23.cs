﻿using System;
using System.Windows.Forms;

namespace spbd_31
{
	// Token: 0x02000008 RID: 8
	internal static class spbd_23
	{
		// Token: 0x0600001A RID: 26 RVA: 0x000020C5 File Offset: 0x000002C5
		[STAThread]
		private static void spbd_121()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);
			Application.Run(new spbd_21());
		}
	}
}
