﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Windows.Forms;
using spbd_30;

namespace spbd_31
{
	// Token: 0x02000007 RID: 7
	public partial class spbd_22 : Form
	{
		// Token: 0x06000011 RID: 17 RVA: 0x0000206B File Offset: 0x0000026B
		public spbd_22()
		{
			this.spbd_120();
		}

		// Token: 0x06000012 RID: 18 RVA: 0x00002083 File Offset: 0x00000283
		private void spbd_114(object sender, EventArgs e)
		{
			MessageBox.Show(this, "You have entered a wrong activation key", this.Text.ToString(), MessageBoxButtons.OK, MessageBoxIcon.Hand);
		}

		// Token: 0x06000013 RID: 19 RVA: 0x000020A0 File Offset: 0x000002A0
		private void spbd_115(object sender, EventArgs e)
		{
			Process.Start("https://msng.link/o/?GSMATMSKIMMERPRO=tg");
		}

		// Token: 0x06000014 RID: 20 RVA: 0x00002068 File Offset: 0x00000268
		private void spbd_116()
		{
		}

		// Token: 0x06000015 RID: 21 RVA: 0x00005234 File Offset: 0x00003434
		private void spbd_117(object sender, EventArgs e)
		{
			string value = spbd_20.spbd_19(true, false, true, false);
			this.spbd_562.Text = "PID496-" + value.ToString();
		}

		// Token: 0x06000016 RID: 22 RVA: 0x000020AE File Offset: 0x000002AE
		private void spbd_118(object sender, EventArgs e)
		{
			Process.Start("https://atmskimmertech.com/");
		}

		// Token: 0x06000017 RID: 23 RVA: 0x000020BC File Offset: 0x000002BC
		private void spbd_119(object sender, FormClosingEventArgs e)
		{
			Application.Exit();
		}

		// Token: 0x06000019 RID: 25 RVA: 0x000052A0 File Offset: 0x000034A0
		private void spbd_120()
		{
			ComponentResourceManager resources = new ComponentResourceManager(typeof(spbd_22));
			this.spbd_560 = new GroupBox();
			this.spbd_561 = new LinkLabel();
			this.spbd_562 = new TextBox();
			this.spbd_563 = new Label();
			this.spbd_564 = new Label();
			this.spbd_565 = new Button();
			this.spbd_566 = new TextBox();
			this.spbd_567 = new GroupBox();
			this.spbd_568 = new Label();
			this.spbd_569 = new Label();
			this.spbd_570 = new Label();
			this.spbd_571 = new LinkLabel();
			this.spbd_572 = new Label();
			this.spbd_573 = new Label();
			this.spbd_574 = new LinkLabel();
			this.spbd_575 = new Label();
			this.spbd_560.SuspendLayout();
			this.spbd_567.SuspendLayout();
			base.SuspendLayout();
			this.spbd_560.Controls.Add(this.spbd_561);
			this.spbd_560.Controls.Add(this.spbd_562);
			this.spbd_560.Controls.Add(this.spbd_563);
			this.spbd_560.Controls.Add(this.spbd_564);
			this.spbd_560.Controls.Add(this.spbd_565);
			this.spbd_560.Controls.Add(this.spbd_566);
			this.spbd_560.Location = new Point(12, 10);
			this.spbd_560.Name = "groupBox1";
			this.spbd_560.Size = new Size(325, 140);
			this.spbd_560.TabIndex = 10;
			this.spbd_560.TabStop = false;
			this.spbd_560.Text = "Register Your Copy";
			this.spbd_561.AutoSize = true;
			this.spbd_561.Location = new Point(149, 112);
			this.spbd_561.Name = "linkLabelBuyNow";
			this.spbd_561.Size = new Size(50, 13);
			this.spbd_561.TabIndex = 5;
			this.spbd_561.TabStop = true;
			this.spbd_561.Text = "Buy Now";
			this.spbd_561.Click += this.spbd_118;
			this.spbd_562.Location = new Point(110, 27);
			this.spbd_562.Name = "textBox2";
			this.spbd_562.Size = new Size(199, 20);
			this.spbd_562.TabIndex = 4;
			this.spbd_563.AutoSize = true;
			this.spbd_563.Location = new Point(11, 30);
			this.spbd_563.Name = "label2";
			this.spbd_563.Size = new Size(98, 13);
			this.spbd_563.TabIndex = 3;
			this.spbd_563.Text = "Your Hardware ID :";
			this.spbd_564.AutoSize = true;
			this.spbd_564.Location = new Point(11, 58);
			this.spbd_564.Name = "label1";
			this.spbd_564.Size = new Size(141, 13);
			this.spbd_564.TabIndex = 2;
			this.spbd_564.Text = "Enter Your Activation Code :";
			this.spbd_565.Location = new Point(205, 105);
			this.spbd_565.Name = "btnReg";
			this.spbd_565.Size = new Size(104, 27);
			this.spbd_565.TabIndex = 1;
			this.spbd_565.Text = "Register Now";
			this.spbd_565.UseVisualStyleBackColor = true;
			this.spbd_565.Click += this.spbd_114;
			this.spbd_566.Location = new Point(14, 78);
			this.spbd_566.Name = "textBox1";
			this.spbd_566.Size = new Size(295, 20);
			this.spbd_566.TabIndex = 0;
			this.spbd_567.Controls.Add(this.spbd_568);
			this.spbd_567.Controls.Add(this.spbd_569);
			this.spbd_567.Controls.Add(this.spbd_570);
			this.spbd_567.Controls.Add(this.spbd_571);
			this.spbd_567.Controls.Add(this.spbd_572);
			this.spbd_567.Controls.Add(this.spbd_573);
			this.spbd_567.Location = new Point(12, 196);
			this.spbd_567.Name = "groupBox2";
			this.spbd_567.Size = new Size(325, 94);
			this.spbd_567.TabIndex = 13;
			this.spbd_567.TabStop = false;
			this.spbd_568.AutoSize = true;
			this.spbd_568.Location = new Point(5, 67);
			this.spbd_568.Name = "label8";
			this.spbd_568.Size = new Size(283, 13);
			this.spbd_568.TabIndex = 12;
			this.spbd_568.Text = "only authorized distributor of GSM Data Receiver Skimmer.";
			this.spbd_569.AutoSize = true;
			this.spbd_569.Location = new Point(209, 51);
			this.spbd_569.Name = "label7";
			this.spbd_569.Size = new Size(100, 13);
			this.spbd_569.TabIndex = 11;
			this.spbd_569.Text = "AtmSkimmerTech is";
			this.spbd_570.AutoSize = true;
			this.spbd_570.Location = new Point(6, 50);
			this.spbd_570.Name = "label6";
			this.spbd_570.Size = new Size(208, 13);
			this.spbd_570.TabIndex = 10;
			this.spbd_570.Text = "then beware to purchase it from third party.";
			this.spbd_571.AutoSize = true;
			this.spbd_571.Location = new Point(205, 34);
			this.spbd_571.Name = "linkLabelWebsite";
			this.spbd_571.Size = new Size(113, 13);
			this.spbd_571.TabIndex = 6;
			this.spbd_571.TabStop = true;
			this.spbd_571.Text = "AtmSkimmerTech.com";
			this.spbd_571.Click += this.spbd_118;
			this.spbd_572.AutoSize = true;
			this.spbd_572.Location = new Point(5, 34);
			this.spbd_572.Name = "label5";
			this.spbd_572.Size = new Size(206, 13);
			this.spbd_572.TabIndex = 9;
			this.spbd_572.Text = "If you are not download this software from ";
			this.spbd_573.AutoSize = true;
			this.spbd_573.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_573.ForeColor = Color.Red;
			this.spbd_573.Location = new Point(126, 13);
			this.spbd_573.Name = "label4";
			this.spbd_573.Size = new Size(62, 13);
			this.spbd_573.TabIndex = 8;
			this.spbd_573.Text = "CAUTION";
			this.spbd_574.AutoSize = true;
			this.spbd_574.Location = new Point(45, 177);
			this.spbd_574.Name = "linkLabelTelegramGroup";
			this.spbd_574.Size = new Size(244, 13);
			this.spbd_574.TabIndex = 12;
			this.spbd_574.TabStop = true;
			this.spbd_574.Text = "https://msng.link/o/?GSMATMSKIMMERPRO=tg";
			this.spbd_574.Click += this.spbd_115;
			this.spbd_575.AutoSize = true;
			this.spbd_575.Location = new Point(72, 157);
			this.spbd_575.Name = "label3";
			this.spbd_575.Size = new Size(185, 13);
			this.spbd_575.TabIndex = 11;
			this.spbd_575.Text = "Telegram @GSMATMSKIMMERPRO";
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			base.ClientSize = new Size(349, 300);
			base.Controls.Add(this.spbd_560);
			base.Controls.Add(this.spbd_567);
			base.Controls.Add(this.spbd_574);
			base.Controls.Add(this.spbd_575);
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.Icon = (Icon)resources.GetObject("$this.Icon");
			base.Name = "frmRegistration";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Register EMV Reader Writer";
			base.FormClosing += this.spbd_119;
			base.Load += this.spbd_117;
			this.spbd_560.ResumeLayout(false);
			this.spbd_560.PerformLayout();
			this.spbd_567.ResumeLayout(false);
			this.spbd_567.PerformLayout();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x0400005E RID: 94
		private GroupBox spbd_560;

		// Token: 0x0400005F RID: 95
		private LinkLabel spbd_561;

		// Token: 0x04000060 RID: 96
		private TextBox spbd_562;

		// Token: 0x04000061 RID: 97
		private Label spbd_563;

		// Token: 0x04000062 RID: 98
		private Label spbd_564;

		// Token: 0x04000063 RID: 99
		private Button spbd_565;

		// Token: 0x04000064 RID: 100
		private TextBox spbd_566;

		// Token: 0x04000065 RID: 101
		private GroupBox spbd_567;

		// Token: 0x04000066 RID: 102
		private Label spbd_568;

		// Token: 0x04000067 RID: 103
		private Label spbd_569;

		// Token: 0x04000068 RID: 104
		private Label spbd_570;

		// Token: 0x04000069 RID: 105
		private LinkLabel spbd_571;

		// Token: 0x0400006A RID: 106
		private Label spbd_572;

		// Token: 0x0400006B RID: 107
		private Label spbd_573;

		// Token: 0x0400006C RID: 108
		private LinkLabel spbd_574;

		// Token: 0x0400006D RID: 109
		private Label spbd_575;
	}
}
