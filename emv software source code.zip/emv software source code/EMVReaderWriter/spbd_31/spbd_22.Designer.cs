﻿namespace spbd_31
{
	// Token: 0x02000007 RID: 7
	public partial class spbd_22 : global::System.Windows.Forms.Form
	{
		// Token: 0x06000018 RID: 24 RVA: 0x00005268 File Offset: 0x00003468
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.spbd_559 != null;
			if (flag)
			{
				this.spbd_559.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x0400005D RID: 93
		private global::System.ComponentModel.IContainer spbd_559 = null;
	}
}
