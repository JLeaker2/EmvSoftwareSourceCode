﻿namespace spbd_31
{
	// Token: 0x02000006 RID: 6
	public partial class spbd_21 : global::System.Windows.Forms.Form
	{
		// Token: 0x0600000F RID: 15 RVA: 0x00002E28 File Offset: 0x00001028
		protected override void Dispose(bool disposing)
		{
			bool flag = disposing && this.spbd_50 != null;
			if (flag)
			{
				this.spbd_50.Dispose();
			}
			base.Dispose(disposing);
		}

		// Token: 0x04000022 RID: 34
		private global::System.ComponentModel.IContainer spbd_50 = null;
	}
}
