﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace spbd_31.spbd_32
{
	// Token: 0x0200000A RID: 10
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	[CompilerGenerated]
	internal sealed partial class spbd_24 : ApplicationSettingsBase
	{
	}
}
