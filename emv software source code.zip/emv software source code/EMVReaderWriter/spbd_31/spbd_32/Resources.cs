﻿using System;
using System.CodeDom.Compiler;
using System.ComponentModel;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.Resources;
using System.Runtime.CompilerServices;

namespace spbd_31.spbd_32
{
	// Token: 0x02000009 RID: 9
	[CompilerGenerated]
	[DebuggerNonUserCode]
	[GeneratedCode("System.Resources.Tools.StronglyTypedResourceBuilder", "16.0.0.0")]
	internal class Resources
	{
		// Token: 0x0600001B RID: 27 RVA: 0x000020E0 File Offset: 0x000002E0
		internal Resources()
		{
		}

		// Token: 0x17000001 RID: 1
		// (get) Token: 0x0600001C RID: 28 RVA: 0x00005CC8 File Offset: 0x00003EC8
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static ResourceManager ResourceManager
		{
			get
			{
				bool flag = Resources.resourceMan == null;
				if (flag)
				{
					ResourceManager temp = new ResourceManager("EMVReaderWriter.Properties.Resources", typeof(Resources).Assembly);
					Resources.resourceMan = temp;
				}
				return Resources.resourceMan;
			}
		}

		// Token: 0x17000002 RID: 2
		// (get) Token: 0x0600001D RID: 29 RVA: 0x00005D10 File Offset: 0x00003F10
		// (set) Token: 0x0600001E RID: 30 RVA: 0x000020EA File Offset: 0x000002EA
		[EditorBrowsable(EditorBrowsableState.Advanced)]
		internal static CultureInfo Culture
		{
			get
			{
				return Resources.resourceCulture;
			}
			set
			{
				Resources.resourceCulture = value;
			}
		}

		// Token: 0x17000003 RID: 3
		// (get) Token: 0x0600001F RID: 31 RVA: 0x00005D28 File Offset: 0x00003F28
		internal static Bitmap bluetooth
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("bluetooth", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000004 RID: 4
		// (get) Token: 0x06000020 RID: 32 RVA: 0x00005D58 File Offset: 0x00003F58
		internal static Bitmap Capture
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("Capture", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000005 RID: 5
		// (get) Token: 0x06000021 RID: 33 RVA: 0x00005D88 File Offset: 0x00003F88
		internal static Bitmap Connect
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("Connect", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000006 RID: 6
		// (get) Token: 0x06000022 RID: 34 RVA: 0x00005DB8 File Offset: 0x00003FB8
		internal static Bitmap EMV_Reader_Writer_Software_v8_6_e1485117187194_600x485_1
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("EMV-Reader-Writer-Software-v8.6-e1485117187194-600x485-1", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000007 RID: 7
		// (get) Token: 0x06000023 RID: 35 RVA: 0x00005DE8 File Offset: 0x00003FE8
		internal static Bitmap EMV2_1024x181_1
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("EMV2-1024x181-1", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000008 RID: 8
		// (get) Token: 0x06000024 RID: 36 RVA: 0x00005E18 File Offset: 0x00004018
		internal static Bitmap Exit
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("Exit", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x17000009 RID: 9
		// (get) Token: 0x06000025 RID: 37 RVA: 0x00005E48 File Offset: 0x00004048
		internal static Bitmap ImportDB
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("ImportDB", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x1700000A RID: 10
		// (get) Token: 0x06000026 RID: 38 RVA: 0x00005E78 File Offset: 0x00004078
		internal static Bitmap Info
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("Info", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x1700000B RID: 11
		// (get) Token: 0x06000027 RID: 39 RVA: 0x00005EA8 File Offset: 0x000040A8
		internal static Bitmap SaveData
		{
			get
			{
				object obj = Resources.ResourceManager.GetObject("SaveData", Resources.resourceCulture);
				return (Bitmap)obj;
			}
		}

		// Token: 0x0400006E RID: 110
		private static ResourceManager resourceMan;

		// Token: 0x0400006F RID: 111
		private static CultureInfo resourceCulture;
	}
}
