﻿using System;
using System.CodeDom.Compiler;
using System.Configuration;
using System.Runtime.CompilerServices;

namespace spbd_31.spbd_32
{
	// Token: 0x0200000A RID: 10
	[GeneratedCode("Microsoft.VisualStudio.Editors.SettingsDesigner.SettingsSingleFileGenerator", "11.0.0.0")]
	[CompilerGenerated]
	internal sealed partial class spbd_24 : ApplicationSettingsBase
	{
		// Token: 0x1700000C RID: 12
		// (get) Token: 0x0600002A RID: 42 RVA: 0x00005ED8 File Offset: 0x000040D8
		public static spbd_24 spbd_40
		{
			get
			{
				return spbd_24.spbd_576;
			}
		}

		// Token: 0x04000070 RID: 112
		private static spbd_24 spbd_576 = (spbd_24)SettingsBase.Synchronized(new spbd_24());
	}
}
