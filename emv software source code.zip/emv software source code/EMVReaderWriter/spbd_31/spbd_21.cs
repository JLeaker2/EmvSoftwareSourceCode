﻿using System;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using spbd_31.spbd_32;

namespace spbd_31
{
	// Token: 0x02000006 RID: 6
	public partial class spbd_21 : Form
	{
		// Token: 0x0600000B RID: 11 RVA: 0x00002050 File Offset: 0x00000250
		public spbd_21()
		{
			this.spbd_113();
		}

		// Token: 0x0600000C RID: 12 RVA: 0x00002068 File Offset: 0x00000268
		private void spbd_110(object sender, EventArgs e)
		{
		}

		// Token: 0x0600000D RID: 13 RVA: 0x00002068 File Offset: 0x00000268
		private void spbd_111(object sender, EventArgs e)
		{
		}

		// Token: 0x0600000E RID: 14 RVA: 0x00002E0C File Offset: 0x0000100C
		private void spbd_112(object sender, EventArgs e)
		{
			spbd_22 show = new spbd_22();
			show.ShowDialog();
		}

		// Token: 0x06000010 RID: 16 RVA: 0x00002E60 File Offset: 0x00001060
		private void spbd_113()
		{
			ComponentResourceManager resources = new ComponentResourceManager(typeof(spbd_21));
			this.spbd_51 = new Label();
			this.spbd_52 = new ComboBox();
			this.spbd_53 = new Button();
			this.spbd_54 = new Label();
			this.spbd_55 = new ComboBox();
			this.spbd_56 = new ComboBox();
			this.spbd_57 = new Label();
			this.spbd_58 = new Label();
			this.spbd_59 = new Label();
			this.spbd_510 = new Label();
			this.spbd_511 = new Label();
			this.spbd_512 = new Label();
			this.spbd_513 = new Label();
			this.spbd_514 = new Label();
			this.spbd_515 = new ProgressBar();
			this.spbd_516 = new TextBox();
			this.spbd_517 = new ComboBox();
			this.spbd_518 = new ComboBox();
			this.spbd_519 = new ComboBox();
			this.spbd_520 = new ComboBox();
			this.spbd_521 = new TextBox();
			this.spbd_522 = new TextBox();
			this.spbd_524 = new Label();
			this.spbd_525 = new Label();
			this.spbd_526 = new Label();
			this.spbd_527 = new Label();
			this.spbd_528 = new CheckBox();
			this.spbd_529 = new CheckBox();
			this.spbd_530 = new Label();
			this.spbd_531 = new Label();
			this.spbd_532 = new CheckBox();
			this.spbd_533 = new Label();
			this.spbd_534 = new Label();
			this.spbd_535 = new CheckBox();
			this.spbd_536 = new CheckBox();
			this.spbd_537 = new CheckBox();
			this.spbd_538 = new TextBox();
			this.spbd_539 = new TextBox();
			this.spbd_540 = new TextBox();
			this.spbd_541 = new TextBox();
			this.spbd_542 = new TextBox();
			this.spbd_543 = new Label();
			this.spbd_544 = new Label();
			this.spbd_545 = new Button();
			this.spbd_546 = new Button();
			this.spbd_548 = new Label();
			this.spbd_549 = new Label();
			this.spbd_552 = new Button();
			this.spbd_556 = new TextBox();
			this.spbd_557 = new Label();
			this.spbd_558 = new Button();
			this.spbd_555 = new Button();
			this.spbd_554 = new Button();
			this.spbd_553 = new Button();
			this.spbd_551 = new Button();
			this.spbd_550 = new Button();
			this.spbd_547 = new Button();
			this.spbd_523 = new PictureBox();
			((ISupportInitialize)this.spbd_523).BeginInit();
			base.SuspendLayout();
			this.spbd_51.AutoSize = true;
			this.spbd_51.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_51.Location = new Point(12, 9);
			this.spbd_51.Name = "label1";
			this.spbd_51.Size = new Size(112, 13);
			this.spbd_51.TabIndex = 0;
			this.spbd_51.Text = "Connect Hardware";
			this.spbd_52.FormattingEnabled = true;
			this.spbd_52.Location = new Point(14, 26);
			this.spbd_52.Name = "comboBox1";
			this.spbd_52.Size = new Size(121, 21);
			this.spbd_52.TabIndex = 1;
			this.spbd_53.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_53.ForeColor = Color.FromArgb(53, 130, 205);
			this.spbd_53.Location = new Point(158, 17);
			this.spbd_53.Name = "button1";
			this.spbd_53.Size = new Size(88, 34);
			this.spbd_53.TabIndex = 2;
			this.spbd_53.Text = "Read Card";
			this.spbd_53.UseVisualStyleBackColor = true;
			this.spbd_54.AutoSize = true;
			this.spbd_54.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_54.Location = new Point(10, 75);
			this.spbd_54.Name = "label2";
			this.spbd_54.Size = new Size(40, 13);
			this.spbd_54.TabIndex = 3;
			this.spbd_54.Text = "Title :";
			this.spbd_55.FormattingEnabled = true;
			this.spbd_55.Location = new Point(102, 71);
			this.spbd_55.Name = "comboBox2";
			this.spbd_55.Size = new Size(52, 21);
			this.spbd_55.TabIndex = 4;
			this.spbd_56.FormattingEnabled = true;
			this.spbd_56.Location = new Point(102, 98);
			this.spbd_56.Name = "comboBox3";
			this.spbd_56.Size = new Size(99, 21);
			this.spbd_56.TabIndex = 5;
			this.spbd_57.AutoSize = true;
			this.spbd_57.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_57.Location = new Point(10, 102);
			this.spbd_57.Name = "label3";
			this.spbd_57.Size = new Size(75, 13);
			this.spbd_57.TabIndex = 6;
			this.spbd_57.Text = "Card Format";
			this.spbd_58.AutoSize = true;
			this.spbd_58.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_58.Location = new Point(10, 128);
			this.spbd_58.Name = "label4";
			this.spbd_58.Size = new Size(69, 13);
			this.spbd_58.TabIndex = 7;
			this.spbd_58.Text = "Card Type ";
			this.spbd_59.AutoSize = true;
			this.spbd_59.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_59.Location = new Point(10, 157);
			this.spbd_59.Name = "label5";
			this.spbd_59.Size = new Size(68, 13);
			this.spbd_59.TabIndex = 8;
			this.spbd_59.Text = "Issue Date";
			this.spbd_510.AutoSize = true;
			this.spbd_510.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_510.Location = new Point(10, 183);
			this.spbd_510.Name = "label6";
			this.spbd_510.Size = new Size(72, 13);
			this.spbd_510.TabIndex = 9;
			this.spbd_510.Text = "Expiry Date";
			this.spbd_511.AutoSize = true;
			this.spbd_511.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_511.Location = new Point(10, 215);
			this.spbd_511.Name = "label7";
			this.spbd_511.Size = new Size(50, 13);
			this.spbd_511.TabIndex = 10;
			this.spbd_511.Text = "Country";
			this.spbd_512.AutoSize = true;
			this.spbd_512.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_512.Location = new Point(10, 250);
			this.spbd_512.Name = "label8";
			this.spbd_512.Size = new Size(67, 13);
			this.spbd_512.TabIndex = 11;
			this.spbd_512.Text = "First Name";
			this.spbd_513.AutoSize = true;
			this.spbd_513.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_513.Location = new Point(10, 276);
			this.spbd_513.Name = "label9";
			this.spbd_513.Size = new Size(67, 13);
			this.spbd_513.TabIndex = 12;
			this.spbd_513.Text = "Last Name";
			this.spbd_514.AutoSize = true;
			this.spbd_514.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_514.Location = new Point(10, 313);
			this.spbd_514.Name = "label10";
			this.spbd_514.Size = new Size(62, 13);
			this.spbd_514.TabIndex = 13;
			this.spbd_514.Text = "Extra Info";
			this.spbd_515.Location = new Point(102, 353);
			this.spbd_515.Name = "progressBar1";
			this.spbd_515.Size = new Size(411, 25);
			this.spbd_515.TabIndex = 14;
			this.spbd_516.Location = new Point(102, 309);
			this.spbd_516.Multiline = true;
			this.spbd_516.Name = "textBox1";
			this.spbd_516.Size = new Size(411, 36);
			this.spbd_516.TabIndex = 15;
			this.spbd_517.FormattingEnabled = true;
			this.spbd_517.Location = new Point(102, 125);
			this.spbd_517.Name = "comboBox4";
			this.spbd_517.Size = new Size(99, 21);
			this.spbd_517.TabIndex = 16;
			this.spbd_518.FormattingEnabled = true;
			this.spbd_518.Location = new Point(102, 152);
			this.spbd_518.Name = "comboBox5";
			this.spbd_518.Size = new Size(152, 21);
			this.spbd_518.TabIndex = 17;
			this.spbd_519.FormattingEnabled = true;
			this.spbd_519.Location = new Point(102, 180);
			this.spbd_519.Name = "comboBox6";
			this.spbd_519.Size = new Size(152, 21);
			this.spbd_519.TabIndex = 18;
			this.spbd_520.FormattingEnabled = true;
			this.spbd_520.Location = new Point(102, 211);
			this.spbd_520.Name = "comboBox7";
			this.spbd_520.Size = new Size(152, 21);
			this.spbd_520.TabIndex = 19;
			this.spbd_521.Location = new Point(102, 245);
			this.spbd_521.Name = "textBox2";
			this.spbd_521.Size = new Size(152, 20);
			this.spbd_521.TabIndex = 20;
			this.spbd_522.Location = new Point(102, 272);
			this.spbd_522.Name = "textBox3";
			this.spbd_522.Size = new Size(152, 20);
			this.spbd_522.TabIndex = 21;
			this.spbd_524.AutoSize = true;
			this.spbd_524.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_524.Location = new Point(273, 204);
			this.spbd_524.Name = "label11";
			this.spbd_524.Size = new Size(51, 13);
			this.spbd_524.TabIndex = 23;
			this.spbd_524.Text = "License";
			this.spbd_525.AutoSize = true;
			this.spbd_525.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_525.Location = new Point(273, 225);
			this.spbd_525.Name = "label12";
			this.spbd_525.Size = new Size(49, 13);
			this.spbd_525.TabIndex = 24;
			this.spbd_525.Text = "HWID -";
			this.spbd_526.AutoSize = true;
			this.spbd_526.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_526.Location = new Point(10, 402);
			this.spbd_526.Name = "label13";
			this.spbd_526.Size = new Size(50, 13);
			this.spbd_526.TabIndex = 25;
			this.spbd_526.Text = "Enable ";
			this.spbd_527.AutoSize = true;
			this.spbd_527.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_527.Location = new Point(114, 402);
			this.spbd_527.Name = "label14";
			this.spbd_527.Size = new Size(11, 13);
			this.spbd_527.TabIndex = 26;
			this.spbd_527.Text = "-";
			this.spbd_528.AutoSize = true;
			this.spbd_528.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_528.Location = new Point(131, 400);
			this.spbd_528.Name = "checkBox1";
			this.spbd_528.Size = new Size(191, 17);
			this.spbd_528.TabIndex = 27;
			this.spbd_528.Text = "Dynamic Data Authentication";
			this.spbd_528.UseVisualStyleBackColor = true;
			this.spbd_529.AutoSize = true;
			this.spbd_529.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_529.Location = new Point(131, 425);
			this.spbd_529.Name = "checkBox2";
			this.spbd_529.Size = new Size(220, 17);
			this.spbd_529.TabIndex = 30;
			this.spbd_529.Text = "Autorization Response Cryptogram";
			this.spbd_529.UseVisualStyleBackColor = true;
			this.spbd_530.AutoSize = true;
			this.spbd_530.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_530.Location = new Point(114, 427);
			this.spbd_530.Name = "label15";
			this.spbd_530.Size = new Size(11, 13);
			this.spbd_530.TabIndex = 29;
			this.spbd_530.Text = "-";
			this.spbd_531.AutoSize = true;
			this.spbd_531.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_531.Location = new Point(10, 427);
			this.spbd_531.Name = "label16";
			this.spbd_531.Size = new Size(95, 13);
			this.spbd_531.TabIndex = 28;
			this.spbd_531.Text = "Load Response";
			this.spbd_532.AutoSize = true;
			this.spbd_532.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_532.Location = new Point(131, 451);
			this.spbd_532.Name = "checkBox3";
			this.spbd_532.Size = new Size(60, 17);
			this.spbd_532.TabIndex = 33;
			this.spbd_532.Text = "ARQC";
			this.spbd_532.UseVisualStyleBackColor = true;
			this.spbd_533.AutoSize = true;
			this.spbd_533.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_533.Location = new Point(114, 453);
			this.spbd_533.Name = "label17";
			this.spbd_533.Size = new Size(11, 13);
			this.spbd_533.TabIndex = 32;
			this.spbd_533.Text = "-";
			this.spbd_534.AutoSize = true;
			this.spbd_534.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_534.Location = new Point(10, 453);
			this.spbd_534.Name = "label18";
			this.spbd_534.Size = new Size(98, 13);
			this.spbd_534.TabIndex = 31;
			this.spbd_534.Text = "Load ARQC Key";
			this.spbd_535.AutoSize = true;
			this.spbd_535.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_535.Location = new Point(12, 490);
			this.spbd_535.Name = "checkBox4";
			this.spbd_535.Size = new Size(78, 17);
			this.spbd_535.TabIndex = 34;
			this.spbd_535.Text = "Track 1#";
			this.spbd_535.UseVisualStyleBackColor = true;
			this.spbd_536.AutoSize = true;
			this.spbd_536.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_536.Location = new Point(12, 518);
			this.spbd_536.Name = "checkBox5";
			this.spbd_536.Size = new Size(78, 17);
			this.spbd_536.TabIndex = 35;
			this.spbd_536.Text = "Track 2#";
			this.spbd_536.UseVisualStyleBackColor = true;
			this.spbd_537.AutoSize = true;
			this.spbd_537.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_537.Location = new Point(12, 541);
			this.spbd_537.Name = "checkBox6";
			this.spbd_537.Size = new Size(78, 17);
			this.spbd_537.TabIndex = 36;
			this.spbd_537.Text = "Track 3#";
			this.spbd_537.UseVisualStyleBackColor = true;
			this.spbd_538.Location = new Point(102, 486);
			this.spbd_538.Name = "textBox4";
			this.spbd_538.Size = new Size(418, 20);
			this.spbd_538.TabIndex = 37;
			this.spbd_539.Location = new Point(102, 512);
			this.spbd_539.Name = "textBox5";
			this.spbd_539.Size = new Size(418, 20);
			this.spbd_539.TabIndex = 38;
			this.spbd_540.Location = new Point(102, 538);
			this.spbd_540.Name = "textBox6";
			this.spbd_540.Size = new Size(418, 20);
			this.spbd_540.TabIndex = 39;
			this.spbd_541.Location = new Point(276, 68);
			this.spbd_541.Name = "textBox7";
			this.spbd_541.Size = new Size(111, 20);
			this.spbd_541.TabIndex = 40;
			this.spbd_542.Location = new Point(276, 99);
			this.spbd_542.Name = "textBox8";
			this.spbd_542.Size = new Size(171, 20);
			this.spbd_542.TabIndex = 41;
			this.spbd_543.AutoSize = true;
			this.spbd_543.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_543.Location = new Point(204, 102);
			this.spbd_543.Name = "label19";
			this.spbd_543.Size = new Size(70, 13);
			this.spbd_543.TabIndex = 42;
			this.spbd_543.Text = "Account #:";
			this.spbd_544.AutoSize = true;
			this.spbd_544.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_544.Location = new Point(228, 72);
			this.spbd_544.Name = "label20";
			this.spbd_544.Size = new Size(41, 13);
			this.spbd_544.TabIndex = 43;
			this.spbd_544.Text = "Pin #:";
			this.spbd_545.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_545.ForeColor = Color.FromArgb(53, 130, 205);
			this.spbd_545.Location = new Point(341, 17);
			this.spbd_545.Name = "button3";
			this.spbd_545.Size = new Size(96, 34);
			this.spbd_545.TabIndex = 45;
			this.spbd_545.Text = "Duplicate Card";
			this.spbd_545.UseVisualStyleBackColor = true;
			this.spbd_546.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_546.ForeColor = Color.FromArgb(35, 130, 205);
			this.spbd_546.Location = new Point(440, 17);
			this.spbd_546.Name = "button4";
			this.spbd_546.Size = new Size(88, 34);
			this.spbd_546.TabIndex = 46;
			this.spbd_546.Text = "Erase Card";
			this.spbd_546.UseVisualStyleBackColor = true;
			this.spbd_548.AutoSize = true;
			this.spbd_548.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_548.ForeColor = Color.ForestGreen;
			this.spbd_548.Location = new Point(335, 204);
			this.spbd_548.Name = "label21";
			this.spbd_548.Size = new Size(35, 13);
			this.spbd_548.TabIndex = 48;
			this.spbd_548.Text = "Valid";
			this.spbd_549.AutoSize = true;
			this.spbd_549.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_549.ForeColor = Color.ForestGreen;
			this.spbd_549.Location = new Point(324, 225);
			this.spbd_549.Name = "label22";
			this.spbd_549.Size = new Size(167, 13);
			this.spbd_549.TabIndex = 49;
			this.spbd_549.Text = "78FR624RE841F8ESQ8FRR";
			this.spbd_552.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_552.ForeColor = Color.FromArgb(35, 130, 205);
			this.spbd_552.Location = new Point(530, 149);
			this.spbd_552.Name = "button8";
			this.spbd_552.Size = new Size(78, 40);
			this.spbd_552.TabIndex = 52;
			this.spbd_552.Text = "Error Check";
			this.spbd_552.UseVisualStyleBackColor = true;
			this.spbd_556.Location = new Point(523, 356);
			this.spbd_556.Name = "textBox9";
			this.spbd_556.Size = new Size(97, 20);
			this.spbd_556.TabIndex = 56;
			this.spbd_557.AutoSize = true;
			this.spbd_557.Font = new Font("Microsoft Sans Serif", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_557.Location = new Point(529, 340);
			this.spbd_557.Name = "label23";
			this.spbd_557.Size = new Size(87, 13);
			this.spbd_557.TabIndex = 57;
			this.spbd_557.Text = "Record Date :";
			this.spbd_558.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_558.ForeColor = Color.FromArgb(53, 130, 205);
			this.spbd_558.Location = new Point(249, 17);
			this.spbd_558.Name = "button2";
			this.spbd_558.Size = new Size(88, 34);
			this.spbd_558.TabIndex = 58;
			this.spbd_558.Text = "Write Card";
			this.spbd_558.UseVisualStyleBackColor = true;
			this.spbd_555.FlatStyle = FlatStyle.Popup;
			this.spbd_555.Image = Resources.Exit;
			this.spbd_555.Location = new Point(530, 283);
			this.spbd_555.Name = "button11";
			this.spbd_555.Size = new Size(78, 40);
			this.spbd_555.TabIndex = 55;
			this.spbd_555.UseVisualStyleBackColor = true;
			this.spbd_554.FlatStyle = FlatStyle.Popup;
			this.spbd_554.Image = Resources.ImportDB;
			this.spbd_554.Location = new Point(530, 237);
			this.spbd_554.Name = "button10";
			this.spbd_554.Size = new Size(78, 40);
			this.spbd_554.TabIndex = 54;
			this.spbd_554.UseVisualStyleBackColor = true;
			this.spbd_553.FlatStyle = FlatStyle.Popup;
			this.spbd_553.Image = Resources.SaveData;
			this.spbd_553.Location = new Point(530, 193);
			this.spbd_553.Name = "button9";
			this.spbd_553.Size = new Size(78, 40);
			this.spbd_553.TabIndex = 53;
			this.spbd_553.UseVisualStyleBackColor = true;
			this.spbd_551.FlatStyle = FlatStyle.Popup;
			this.spbd_551.Image = Resources.bluetooth;
			this.spbd_551.Location = new Point(530, 103);
			this.spbd_551.Name = "button7";
			this.spbd_551.Size = new Size(78, 40);
			this.spbd_551.TabIndex = 51;
			this.spbd_551.UseVisualStyleBackColor = true;
			this.spbd_550.FlatStyle = FlatStyle.Popup;
			this.spbd_550.Image = Resources.Connect;
			this.spbd_550.Location = new Point(530, 60);
			this.spbd_550.Name = "button6";
			this.spbd_550.Size = new Size(78, 40);
			this.spbd_550.TabIndex = 50;
			this.spbd_550.UseVisualStyleBackColor = true;
			this.spbd_547.Font = new Font("Microsoft Tai Le", 8.25f, FontStyle.Bold, GraphicsUnit.Point, 0);
			this.spbd_547.ForeColor = Color.FromArgb(35, 130, 205);
			this.spbd_547.Image = Resources.Info;
			this.spbd_547.Location = new Point(530, 17);
			this.spbd_547.Name = "button5";
			this.spbd_547.Size = new Size(78, 40);
			this.spbd_547.TabIndex = 47;
			this.spbd_547.UseVisualStyleBackColor = true;
			this.spbd_523.Image = Resources.EMV2_1024x181_1;
			this.spbd_523.Location = new Point(276, 151);
			this.spbd_523.Name = "pictureBox1";
			this.spbd_523.Size = new Size(244, 45);
			this.spbd_523.SizeMode = PictureBoxSizeMode.Zoom;
			this.spbd_523.TabIndex = 22;
			this.spbd_523.TabStop = false;
			this.spbd_523.Click += this.spbd_110;
			base.AutoScaleDimensions = new SizeF(6f, 13f);
			base.AutoScaleMode = AutoScaleMode.Font;
			this.BackgroundImageLayout = ImageLayout.None;
			base.ClientSize = new Size(628, 575);
			base.Controls.Add(this.spbd_558);
			base.Controls.Add(this.spbd_557);
			base.Controls.Add(this.spbd_556);
			base.Controls.Add(this.spbd_555);
			base.Controls.Add(this.spbd_554);
			base.Controls.Add(this.spbd_553);
			base.Controls.Add(this.spbd_552);
			base.Controls.Add(this.spbd_551);
			base.Controls.Add(this.spbd_550);
			base.Controls.Add(this.spbd_549);
			base.Controls.Add(this.spbd_548);
			base.Controls.Add(this.spbd_547);
			base.Controls.Add(this.spbd_546);
			base.Controls.Add(this.spbd_545);
			base.Controls.Add(this.spbd_544);
			base.Controls.Add(this.spbd_543);
			base.Controls.Add(this.spbd_542);
			base.Controls.Add(this.spbd_541);
			base.Controls.Add(this.spbd_540);
			base.Controls.Add(this.spbd_539);
			base.Controls.Add(this.spbd_538);
			base.Controls.Add(this.spbd_537);
			base.Controls.Add(this.spbd_536);
			base.Controls.Add(this.spbd_535);
			base.Controls.Add(this.spbd_532);
			base.Controls.Add(this.spbd_533);
			base.Controls.Add(this.spbd_534);
			base.Controls.Add(this.spbd_529);
			base.Controls.Add(this.spbd_530);
			base.Controls.Add(this.spbd_531);
			base.Controls.Add(this.spbd_528);
			base.Controls.Add(this.spbd_527);
			base.Controls.Add(this.spbd_526);
			base.Controls.Add(this.spbd_525);
			base.Controls.Add(this.spbd_524);
			base.Controls.Add(this.spbd_523);
			base.Controls.Add(this.spbd_522);
			base.Controls.Add(this.spbd_521);
			base.Controls.Add(this.spbd_520);
			base.Controls.Add(this.spbd_519);
			base.Controls.Add(this.spbd_518);
			base.Controls.Add(this.spbd_517);
			base.Controls.Add(this.spbd_516);
			base.Controls.Add(this.spbd_515);
			base.Controls.Add(this.spbd_514);
			base.Controls.Add(this.spbd_513);
			base.Controls.Add(this.spbd_512);
			base.Controls.Add(this.spbd_511);
			base.Controls.Add(this.spbd_510);
			base.Controls.Add(this.spbd_59);
			base.Controls.Add(this.spbd_58);
			base.Controls.Add(this.spbd_57);
			base.Controls.Add(this.spbd_56);
			base.Controls.Add(this.spbd_55);
			base.Controls.Add(this.spbd_54);
			base.Controls.Add(this.spbd_53);
			base.Controls.Add(this.spbd_52);
			base.Controls.Add(this.spbd_51);
			this.DoubleBuffered = true;
			base.FormBorderStyle = FormBorderStyle.FixedSingle;
			base.Icon = (Icon)resources.GetObject("$this.Icon");
			base.MaximizeBox = false;
			base.Name = "frmMain";
			base.StartPosition = FormStartPosition.CenterScreen;
			this.Text = "Emv Reader Writer Software 8 .6";
			base.Load += this.spbd_111;
			base.Shown += this.spbd_112;
			((ISupportInitialize)this.spbd_523).EndInit();
			base.ResumeLayout(false);
			base.PerformLayout();
		}

		// Token: 0x04000023 RID: 35
		private Label spbd_51;

		// Token: 0x04000024 RID: 36
		private ComboBox spbd_52;

		// Token: 0x04000025 RID: 37
		private Button spbd_53;

		// Token: 0x04000026 RID: 38
		private Label spbd_54;

		// Token: 0x04000027 RID: 39
		private ComboBox spbd_55;

		// Token: 0x04000028 RID: 40
		private ComboBox spbd_56;

		// Token: 0x04000029 RID: 41
		private Label spbd_57;

		// Token: 0x0400002A RID: 42
		private Label spbd_58;

		// Token: 0x0400002B RID: 43
		private Label spbd_59;

		// Token: 0x0400002C RID: 44
		private Label spbd_510;

		// Token: 0x0400002D RID: 45
		private Label spbd_511;

		// Token: 0x0400002E RID: 46
		private Label spbd_512;

		// Token: 0x0400002F RID: 47
		private Label spbd_513;

		// Token: 0x04000030 RID: 48
		private Label spbd_514;

		// Token: 0x04000031 RID: 49
		private ProgressBar spbd_515;

		// Token: 0x04000032 RID: 50
		private TextBox spbd_516;

		// Token: 0x04000033 RID: 51
		private ComboBox spbd_517;

		// Token: 0x04000034 RID: 52
		private ComboBox spbd_518;

		// Token: 0x04000035 RID: 53
		private ComboBox spbd_519;

		// Token: 0x04000036 RID: 54
		private ComboBox spbd_520;

		// Token: 0x04000037 RID: 55
		private TextBox spbd_521;

		// Token: 0x04000038 RID: 56
		private TextBox spbd_522;

		// Token: 0x04000039 RID: 57
		private PictureBox spbd_523;

		// Token: 0x0400003A RID: 58
		private Label spbd_524;

		// Token: 0x0400003B RID: 59
		private Label spbd_525;

		// Token: 0x0400003C RID: 60
		private Label spbd_526;

		// Token: 0x0400003D RID: 61
		private Label spbd_527;

		// Token: 0x0400003E RID: 62
		private CheckBox spbd_528;

		// Token: 0x0400003F RID: 63
		private CheckBox spbd_529;

		// Token: 0x04000040 RID: 64
		private Label spbd_530;

		// Token: 0x04000041 RID: 65
		private Label spbd_531;

		// Token: 0x04000042 RID: 66
		private CheckBox spbd_532;

		// Token: 0x04000043 RID: 67
		private Label spbd_533;

		// Token: 0x04000044 RID: 68
		private Label spbd_534;

		// Token: 0x04000045 RID: 69
		private CheckBox spbd_535;

		// Token: 0x04000046 RID: 70
		private CheckBox spbd_536;

		// Token: 0x04000047 RID: 71
		private CheckBox spbd_537;

		// Token: 0x04000048 RID: 72
		private TextBox spbd_538;

		// Token: 0x04000049 RID: 73
		private TextBox spbd_539;

		// Token: 0x0400004A RID: 74
		private TextBox spbd_540;

		// Token: 0x0400004B RID: 75
		private TextBox spbd_541;

		// Token: 0x0400004C RID: 76
		private TextBox spbd_542;

		// Token: 0x0400004D RID: 77
		private Label spbd_543;

		// Token: 0x0400004E RID: 78
		private Label spbd_544;

		// Token: 0x0400004F RID: 79
		private Button spbd_545;

		// Token: 0x04000050 RID: 80
		private Button spbd_546;

		// Token: 0x04000051 RID: 81
		private Button spbd_547;

		// Token: 0x04000052 RID: 82
		private Label spbd_548;

		// Token: 0x04000053 RID: 83
		private Label spbd_549;

		// Token: 0x04000054 RID: 84
		private Button spbd_550;

		// Token: 0x04000055 RID: 85
		private Button spbd_551;

		// Token: 0x04000056 RID: 86
		private Button spbd_552;

		// Token: 0x04000057 RID: 87
		private Button spbd_553;

		// Token: 0x04000058 RID: 88
		private Button spbd_554;

		// Token: 0x04000059 RID: 89
		private Button spbd_555;

		// Token: 0x0400005A RID: 90
		private TextBox spbd_556;

		// Token: 0x0400005B RID: 91
		private Label spbd_557;

		// Token: 0x0400005C RID: 92
		private Button spbd_558;
	}
}
