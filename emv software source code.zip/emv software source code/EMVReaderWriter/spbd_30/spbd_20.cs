﻿using System;
using System.Collections;
using System.Management;
using System.Runtime.InteropServices;
using System.Security.Cryptography;
using System.Text;

namespace spbd_30
{
	// Token: 0x02000002 RID: 2
	public static class spbd_20
	{
		// Token: 0x06000001 RID: 1
		[DllImport("iphlpapi.dll", CharSet = CharSet.Ansi, EntryPoint = "GetAdaptersInfo")]
		public static extern int spbd_10(IntPtr intptr0, ref long long0);

		// Token: 0x06000002 RID: 2 RVA: 0x00002114 File Offset: 0x00000314
		internal static string spbd_11()
		{
			string text = string.Empty;
			try
			{
				long value = (long)Marshal.SizeOf(typeof(spbd_20.spbd_26));
				IntPtr intPtr = Marshal.AllocHGlobal(new IntPtr(value));
				int adaptersInfo = spbd_20.spbd_10(intPtr, ref value);
				bool flag = adaptersInfo == 111;
				if (flag)
				{
					intPtr = Marshal.ReAllocHGlobal(intPtr, new IntPtr(value));
					adaptersInfo = spbd_20.spbd_10(intPtr, ref value);
				}
				bool flag2 = adaptersInfo == 0;
				if (flag2)
				{
					IntPtr ptr = intPtr;
					spbd_20.spbd_26 ipAdapterInfo = (spbd_20.spbd_26)Marshal.PtrToStructure(ptr, typeof(spbd_20.spbd_26));
					int i = 0;
					while ((long)i < (long)((ulong)ipAdapterInfo.spbd_588))
					{
						text += ipAdapterInfo.spbd_589[i].ToString("X2");
						i++;
					}
					Marshal.FreeHGlobal(intPtr);
				}
				else
				{
					Marshal.FreeHGlobal(intPtr);
				}
			}
			catch
			{
			}
			bool flag3 = text == string.Empty;
			if (flag3)
			{
				text = "";
			}
			return text;
		}

		// Token: 0x06000003 RID: 3 RVA: 0x00002224 File Offset: 0x00000424
		private static string spbd_12()
		{
			string text = string.Empty;
			try
			{
				ManagementClass managementClass = new ManagementClass("Win32_Processor");
				ManagementObjectCollection instances = managementClass.GetInstances();
				foreach (ManagementBaseObject managementBaseObject in instances)
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					bool flag = text != string.Empty;
					if (!flag)
					{
						try
						{
							text = managementObject.Properties["ProcessorId"].Value.ToString();
							bool flag2 = text.Length != 0;
							if (flag2)
							{
								break;
							}
							text = string.Empty;
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			return text;
		}

		// Token: 0x06000004 RID: 4 RVA: 0x00002308 File Offset: 0x00000508
		private static string spbd_13()
		{
			string text = string.Empty;
			try
			{
				text = spbd_20.spbd_11();
				bool flag = text.Length == 0;
				if (flag)
				{
					text = string.Empty;
					ManagementClass managementClass = new ManagementClass("Win32_NetworkAdapterConfiguration");
					ManagementObjectCollection instances = managementClass.GetInstances();
					foreach (ManagementBaseObject managementBaseObject in instances)
					{
						ManagementObject managementObject = (ManagementObject)managementBaseObject;
						bool flag2 = text != string.Empty;
						if (flag2)
						{
							break;
						}
						try
						{
							bool flag3 = managementObject["IPEnabled"] != null && (bool)managementObject["IPEnabled"] && managementObject["MacAddress"] != null && managementObject["MacAddress"].ToString().Length > 0;
							if (flag3)
							{
								text = managementObject["MacAddress"].ToString().ToUpper();
								text = text.Replace(":", "");
							}
						}
						catch
						{
						}
					}
				}
			}
			catch
			{
			}
			return text;
		}

		// Token: 0x06000005 RID: 5 RVA: 0x00002484 File Offset: 0x00000684
		private static string spbd_14()
		{
			string result;
			try
			{
				result = string.Concat(new string[]
				{
					spbd_20.spbd_17(),
					"-",
					spbd_20.spbd_15(),
					"-",
					spbd_20.spbd_16()
				});
			}
			catch
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000006 RID: 6 RVA: 0x000024E4 File Offset: 0x000006E4
		private static string spbd_15()
		{
			string result;
			try
			{
				string text = string.Empty;
				ManagementClass managementClass = new ManagementClass("Win32_BaseBoard");
				ManagementObjectCollection instances = managementClass.GetInstances();
				foreach (ManagementBaseObject managementBaseObject in instances)
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					try
					{
						bool flag = text == string.Empty && managementObject.Properties["Manufacturer"].Value != null;
						if (flag)
						{
							text = managementObject.Properties["Manufacturer"].Value.ToString();
							bool flag2 = text.Length != 0;
							if (flag2)
							{
								break;
							}
							text = string.Empty;
						}
					}
					catch
					{
					}
				}
				result = text;
			}
			catch
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000007 RID: 7 RVA: 0x000025F4 File Offset: 0x000007F4
		private static string spbd_16()
		{
			string result;
			try
			{
				string text = string.Empty;
				ManagementClass managementClass = new ManagementClass("Win32_BaseBoard");
				ManagementObjectCollection instances = managementClass.GetInstances();
				foreach (ManagementBaseObject managementBaseObject in instances)
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					try
					{
						bool flag = text == string.Empty && managementObject.Properties["SerialNumber"].Value != null;
						if (flag)
						{
							text = managementObject.Properties["SerialNumber"].Value.ToString();
							bool flag2 = text.Length != 0;
							if (flag2)
							{
								break;
							}
							text = string.Empty;
						}
					}
					catch
					{
					}
				}
				result = text;
			}
			catch
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000008 RID: 8 RVA: 0x00002704 File Offset: 0x00000904
		private static string spbd_17()
		{
			string result;
			try
			{
				string text = string.Empty;
				ManagementClass managementClass = new ManagementClass("Win32_BaseBoard");
				ManagementObjectCollection instances = managementClass.GetInstances();
				foreach (ManagementBaseObject managementBaseObject in instances)
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					try
					{
						bool flag = managementObject.Properties["Product"].Value != null && text == string.Empty;
						if (flag)
						{
							text = managementObject.Properties["Product"].Value.ToString();
							bool flag2 = text.Length != 0;
							if (flag2)
							{
								break;
							}
							text = string.Empty;
						}
					}
					catch
					{
					}
				}
				result = text;
			}
			catch
			{
				result = string.Empty;
			}
			return result;
		}

		// Token: 0x06000009 RID: 9 RVA: 0x00002810 File Offset: 0x00000A10
		private static string spbd_18()
		{
			try
			{
				ArrayList arrayList = new ArrayList();
				ManagementObjectSearcher managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_DiskDrive");
				foreach (ManagementBaseObject managementBaseObject in managementObjectSearcher.Get())
				{
					ManagementObject managementObject = (ManagementObject)managementBaseObject;
					bool flag2 = managementObject["DeviceID"] == null || managementObject["InterfaceType"] == null || managementObject["InterfaceType"].ToString() == "USB" || managementObject["InterfaceType"].ToString() == "195714";
					if (!flag2)
					{
						bool flag = managementObject["MediaType"] == null || !(managementObject["MediaType"].ToString() == "Removable Media");
						bool flag3 = !flag;
						if (!flag3)
						{
							object obj = managementObject["SerialNumber"];
							bool flag4 = obj != null && obj.ToString().Trim() != string.Empty && obj.ToString()[0] != Convert.ToChar(31);
							if (flag4)
							{
								return obj.ToString().Trim();
							}
							arrayList.Add(managementObject["DeviceID"].ToString());
						}
					}
				}
				managementObjectSearcher = new ManagementObjectSearcher("SELECT * FROM Win32_PhysicalMedia");
				ManagementObjectCollection managementObjectCollection = managementObjectSearcher.Get();
				foreach (object obj3 in arrayList)
				{
					string b = (string)obj3;
					foreach (ManagementBaseObject managementBaseObject2 in managementObjectCollection)
					{
						ManagementObject managementObject2 = (ManagementObject)managementBaseObject2;
						bool flag5 = managementObject2["Tag"] == null;
						if (!flag5)
						{
							string a = managementObject2["Tag"].ToString();
							bool flag6 = a != b || managementObject2["SerialNumber"] == null;
							if (!flag6)
							{
								object obj2 = managementObject2["SerialNumber"];
								bool flag7 = obj2 != null && obj2.ToString() != string.Empty && obj2.ToString()[0] != Convert.ToChar(31);
								if (flag7)
								{
									return obj2.ToString().Trim().Replace(" ", "");
								}
								break;
							}
						}
					}
				}
			}
			catch
			{
				return string.Empty;
			}
			return string.Empty;
		}

		// Token: 0x0600000A RID: 10 RVA: 0x00002B50 File Offset: 0x00000D50
		internal static string spbd_19(bool proccessor, bool mac, bool motherboard, bool disk)
		{
			string text = "";
			RSACryptoServiceProvider.UseMachineKeyStore = true;
			MD5 md5 = MD5.Create();
			if (proccessor)
			{
				byte[] array = md5.ComputeHash(Encoding.Unicode.GetBytes(spbd_20.spbd_12()));
				text += array[3].ToString("X2");
				text = text + array[14].ToString("X2") + "-";
			}
			else
			{
				text = "85C1-";
			}
			if (mac)
			{
				byte[] array2 = md5.ComputeHash(Encoding.Unicode.GetBytes(spbd_20.spbd_13()));
				text += array2[3].ToString("X2");
				text = text + array2[3].ToString("X2") + "-";
			}
			else
			{
				byte[] array3 = md5.ComputeHash(Encoding.Unicode.GetBytes(text));
				text += array3[15].ToString("X2");
				text = text + array3[4].ToString("X2") + "-";
			}
			if (motherboard)
			{
				byte[] array4 = md5.ComputeHash(Encoding.Unicode.GetBytes(spbd_20.spbd_14()));
				text += array4[3].ToString("X2");
				text = text + array4[9].ToString("X2") + "-";
			}
			else
			{
				byte[] array5 = md5.ComputeHash(Encoding.Unicode.GetBytes(text));
				text += array5[2].ToString("X2");
				text = text + array5[17].ToString("X2") + "-";
			}
			if (disk)
			{
				byte[] array6 = md5.ComputeHash(Encoding.Unicode.GetBytes(spbd_20.spbd_18()));
				text += array6[3].ToString("X2");
				text = text + array6[14].ToString("X2") + "-";
			}
			else
			{
				byte[] array7 = md5.ComputeHash(Encoding.Unicode.GetBytes(text));
				text += array7[1].ToString("X2");
				text = text + array7[8].ToString("X2") + "-";
			}
			byte[] array8 = md5.ComputeHash(Encoding.Unicode.GetBytes(text));
			text += array8[1].ToString("X2");
			return text + array8[8].ToString("X2");
		}

		// Token: 0x02000003 RID: 3
		internal struct spbd_25
		{
			// Token: 0x04000001 RID: 1
			internal IntPtr spbd_577;

			// Token: 0x04000002 RID: 2
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
			internal string spbd_578;

			// Token: 0x04000003 RID: 3
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 16)]
			internal string spbd_579;

			// Token: 0x04000004 RID: 4
			internal uint spbd_580;
		}

		// Token: 0x02000004 RID: 4
		internal struct spbd_26
		{
			// Token: 0x04000005 RID: 5
			internal const int spbd_581 = 128;

			// Token: 0x04000006 RID: 6
			internal const int spbd_582 = 256;

			// Token: 0x04000007 RID: 7
			internal const int spbd_583 = 8;

			// Token: 0x04000008 RID: 8
			internal IntPtr spbd_584;

			// Token: 0x04000009 RID: 9
			internal uint spbd_585;

			// Token: 0x0400000A RID: 10
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 260)]
			internal string spbd_586;

			// Token: 0x0400000B RID: 11
			[MarshalAs(UnmanagedType.ByValTStr, SizeConst = 132)]
			internal string spbd_587;

			// Token: 0x0400000C RID: 12
			internal uint spbd_588;

			// Token: 0x0400000D RID: 13
			[MarshalAs(UnmanagedType.ByValArray, SizeConst = 8)]
			internal byte[] spbd_589;

			// Token: 0x0400000E RID: 14
			internal uint spbd_590;

			// Token: 0x0400000F RID: 15
			internal spbd_20.spbd_27 spbd_591;

			// Token: 0x04000010 RID: 16
			internal bool spbd_592;

			// Token: 0x04000011 RID: 17
			internal IntPtr spbd_593;

			// Token: 0x04000012 RID: 18
			internal spbd_20.spbd_25 spbd_594;

			// Token: 0x04000013 RID: 19
			internal spbd_20.spbd_25 spbd_595;

			// Token: 0x04000014 RID: 20
			internal spbd_20.spbd_25 spbd_596;

			// Token: 0x04000015 RID: 21
			[MarshalAs(UnmanagedType.Bool)]
			internal bool spbd_597;

			// Token: 0x04000016 RID: 22
			internal spbd_20.spbd_25 spbd_598;

			// Token: 0x04000017 RID: 23
			internal spbd_20.spbd_25 spbd_599;

			// Token: 0x04000018 RID: 24
			internal uint spbd_5100;

			// Token: 0x04000019 RID: 25
			internal uint spbd_5101;
		}

		// Token: 0x02000005 RID: 5
		internal enum spbd_27
		{
			// Token: 0x0400001B RID: 27
			spbd_5102 = 6,
			// Token: 0x0400001C RID: 28
			spbd_5103 = 15,
			// Token: 0x0400001D RID: 29
			spbd_5104 = 24,
			// Token: 0x0400001E RID: 30
			spbd_5105 = 23,
			// Token: 0x0400001F RID: 31
			spbd_5106 = 28,
			// Token: 0x04000020 RID: 32
			spbd_5107 = 9,
			// Token: 0x04000021 RID: 33
			spbd_5108 = 0
		}
	}
}
